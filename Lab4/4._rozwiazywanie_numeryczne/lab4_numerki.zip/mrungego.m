function [ T, X ] = mrungego( f, tspan, x0, dt )
%MRUNGEGO Funkcja numerycznie rozwi�zuj�ca r�wnanie r�niczkowe metod�
%Rungego-Kutty
%   Detailed explanation goes here
T = tspan(1):dt:tspan(2);
[m,n] = size(x0);
if ( m ~= 1 && n == 1 )
    x0 = x0';
end
X = zeros(length(T), length(x0));
X(1,:) = x0;
for i=1:length(T)-1
    k1 = feval(f, T(i), X(i,:)' );
    k2 = feval(f, T(i) + dt/2, X(i,:)' + (dt/2)*k1);
    k3 = feval(f, T(i) + dt/2, X(i,:)' + (dt/2)*k2);
    k4 = feval(f, T(i) + dt, X(i,:)' + dt*k3);
    X(i+1,:) = X(i,:) + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)';
end
T = T';
end

