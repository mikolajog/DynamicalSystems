function xp = arenstorf( t, x )
%ARENSTORF Summary of this function goes here
%   Detailed explanation goes here
u = 0.012277471;

% przydzielenie pami�ci
xp = zeros( size(x) );

% obliczanie zmiennych
d1 = (( x(1) + u )^2 + x(3)^2)^1.5;
d2 = (( x(1) - (1-u) )^2 + x(3)^2)^1.5;

xp(1) = x(2);
xp(2) = x(1) + 2*x(4) - (1-u)*(x(1) + u)/d1 - u*(x(1) - (1-u) )/d2;
xp(3) = x(4);
xp(4) = x(3) - 2*x(2) - (1-u)*x(3)/d1 - u*x(3)/d2;
end

