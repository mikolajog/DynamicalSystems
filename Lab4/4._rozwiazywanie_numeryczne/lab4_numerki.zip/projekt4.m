clear all;

x0 = zeros(4,1);
x0(1) = 0.994;
x0(2) = 0;
x0(3) = 0;
x0(4) = -2.00158510637908252240537862224;

T = 17.0652165601579625588917206249;

Edt = 0.0001;
RKdt = 0.001;

[ tout, X ] = meuler(@arenstorf, [0 T], x0, Edt);
[ toutRK, XRK ] = mrungego(@arenstorf, [0 T], x0, RKdt);
[ toutODE, XODE ] = ode45(@arenstorf, [0 T], x0);

plot(X(:,1), X(:,3), 'r',XRK(:,1), XRK(:,3), 'g', XODE(:,1), XODE(:,3), 'b');
