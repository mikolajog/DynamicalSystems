function [ T, X ] = meuler( f, tspan, x0, dt )
%MEULER Funkcja numerycznie rozwi�zuj�ca r�wnanie r�niczkowe metod� Eulera
%f - f( x(t), t )
%Tmax - czas do kt�rego rozwi�zujemy r�wnianie
%x0 - warunki pocz�tkowe
%dt - krok metody
T = tspan(1):dt:tspan(2);
[m,n] = size(x0);
if ( m ~= 1 && n == 1 )
    x0 = x0';
end
X = zeros(length(T), length(x0));
X(1,:) = x0;
for i=1:length(T)-1
    X(i+1,:) = X(i,:) + dt*feval(f , T(i), X(i,:)' )';
end
T = T';
end

