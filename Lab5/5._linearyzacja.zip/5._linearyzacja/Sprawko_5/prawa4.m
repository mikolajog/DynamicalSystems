
function w=prawa(t,x,eps)
 % epsilon = 6
  w=-x+eps*x^2;
end