
function w=prawa(t,x)
 % epsilon = 6
  w=-x+0.5*x^2;
end