
function w=prawa(t,x)
 % epsilon = 6
  w(1)=-x(1);
  w(2)=-x(2)^2;
end