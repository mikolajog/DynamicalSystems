function w=prawa15(t,x)
  w(1)=x(2);
  w(2)=2*x(1)-x(2);
end