function w=prawa1eps(t,x,eps)
    w = -x + eps * x^2;
end 