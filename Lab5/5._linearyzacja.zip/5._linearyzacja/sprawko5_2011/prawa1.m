function w=prawa1(t,x)
    eps = 0.5;
    w= -x + eps * x^2;
end 