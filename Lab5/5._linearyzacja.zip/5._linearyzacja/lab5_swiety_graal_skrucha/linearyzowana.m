function y=linearyzowana(t,x)
  y(1)=x(2);
  y(2)=-2*x(1)-3*x(1)^2-x(2);
end